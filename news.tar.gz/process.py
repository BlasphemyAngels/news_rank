import os
import sys
import logging
import argparse
import re
from tqdm import tqdm
import jieba
from utils import read_data
from utils import filter_time_num_etc
from utils import get_stop_list
from utils import store_cut_data


import pandas as pd

def remove_time(titles):
    new_titles = []
    for title in titles:
        new_titles.append(filter_time_num_etc(title))
    return new_titles

if __name__ == '__main__':
    
    logging.basicConfig(format="%(asctime)s : %(levelname)s : %(message)s")
    logging.root.setLevel(logging.INFO)

    parser = argparse.ArgumentParser()
    
    parser.add_argument("--use_stop", type=bool, default=True, help="是否使用停用词")
    parser.add_argument("--train_data", type=str, default="train_data.csv", help="训练数据")
    parser.add_argument("--test_data", type=str, default="test_data.csv", help="数据")
    parser.add_argument("--stop_path", type=str, default="stop.txt", help="停用词表的文件路径")

    args, _ = parser.parse_known_args()


    train = pd.read_csv(args.train_data)
    test = pd.read_csv(args.test_data, encoding="gbk")

    titles_train = train["title"].tolist()
    titles_test = test["title"].tolist()

    stop_list = get_stop_list(args.stop_path)

    titles_train = remove_time(titles_train)
    titles_test = remove_time(titles_test)

    cut_titles_train = []
    for title in tqdm(titles_train):
        cut_title_train = jieba.cut(title)
        cut_title_train = [word for word in cut_title_train if args.use_stop and (word not in stop_list)]
        cut_titles_train.append(cut_title_train)

    cut_titles_test = []

    for title in tqdm(titles_test):
        cut_title_test = jieba.cut(title)
        cut_title_test = [word for word in cut_title_test if args.use_stop and (word not in stop_list)]
        cut_titles_test.append(cut_title_test)

    store_cut_data("cut_train.csv", train, cut_titles_train)
    print(len(test))
    store_cut_data("cut_test.csv", test, cut_titles_test)

