import os
import sys

from gensim import corpora
from gensim import similarities
from gensim import models

from utils import write_res



def read_data(filename):
    ids = []
    titles = []
    with open(filename, "r") as f:
        lines = f.readlines()
        
        for line in lines:
            lineSplit = line.split(",")
            ids.append(lineSplit[0])
            titles.append(lineSplit[1].split())
    return ids, titles

def filter_words(data, dictionary):

    f_data = []

    for d in data:

        ans = []

        for word in d:
            if(word in dictionary):
                ans.append(word)
        f_data.append(ans)
    return f_data


if __name__ == '__main__':

    train_ids, train_titles = read_data("./cut_train.csv")
    test_ids, test_titles = read_data("./cut_test.csv")

    print(test_ids[0])
    print(train_titles[0])

    dictionary = corpora.Dictionary(train_titles)

    print(len(dictionary))

    #  train_titles = filter_words(train_titles, dictionary.keys())
    #  test_titles = filter_words(test_titles, dictionary.keys())

    corpus = [dictionary.doc2bow(text) for text in train_titles]

    tfidf_model = models.TfidfModel(corpus)
    corpus_tfidf = tfidf_model[corpus]

    print(len(corpus_tfidf))

    print(corpus_tfidf[0])
    #  lsi = models.LsiModel(corpus_tfidf)
    #  corpus_lsi = lsi[corpus_tfidf]

    simility = similarities.Similarity("Similarity-tfidf-index", corpus_tfidf, num_features=len(dictionary))

    #  simility = similarities.Similarity("Similarity-LSI-index", corpus_lsi, num_features=len(dictionary))


    res = []

    simility.num_best = 21
    for i in range(len(test_ids)):
        id_ = test_ids[i]
        title_ = test_titles[i]

        title_bow = dictionary.doc2bow(title_)

        title_bow_tfidf = tfidf_model[title_bow]
        
        #  title_bow_lsi = lsi[title_bow_tfidf]

        best_sims = simility[title_bow_tfidf]
        #  best_sims.reverse()

        for best_sim in best_sims:

            if(id_ != train_ids[best_sim[0]]):
                res.append([id_, train_ids[best_sim[0]]])

    write_res("res2.txt", res)
