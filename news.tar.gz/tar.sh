tar -zcvf news.tar.gz --exclude=Similarity* --exclude=*data.csv --exclude=__pycache__/ --exclude=*.txt --exclude=word2vec* --exclude=*.tar.gz --exclude=doc2vec* *
