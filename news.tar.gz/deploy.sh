sh tar.sh

scp -r news.tar.gz neukg6@219.216.64.90:/home/neukg6/a
