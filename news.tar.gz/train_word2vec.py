import argparse
import logging

from gensim.models import Word2Vec

from utils import read_data

if __name__ == '__main__':

    logging.root.setLevel(logging.INFO)

    logging.basicConfig(format="%(asctime)s : %(levelname)s : %(message)s")

    logger = logging.getLogger()

    parser = argparse.ArgumentParser()

    parser.add_argument("--embedding_size", type=int, default=80, help="词向量的维度")
    parser.add_argument("--min_count", type=int, default=1, help="word2vec模型中词典词语出现的最小次数，小于这个次数的词语将被舍弃")
    parser.add_argument("--store_path", type=str, default="word2vec.model", help="模型保存的路径")

    args, _ = parser.parse_known_args()

    embedding_size = args.embedding_size
    min_count = args.min_count
    store_path = args.store_path


    train_ids, train_titles = read_data("./cut_train.csv")
    test_ids, test_titles = read_data("./cut_test.csv")

    
    logger.info("Start train word2vec model...")
    model = Word2Vec(train_titles, size=embedding_size, min_count=min_count)
    model.save(store_path)
    logger.info("End trainning.")

    vocab = model.wv.vocab
    print(len(vocab))
    
