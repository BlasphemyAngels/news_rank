from tqdm import tqdm

for i in tqdm(range(10)):
    print("hehe")
