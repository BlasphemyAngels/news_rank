import os
import sys

import re

import numpy as np
import pandas as pd
from tqdm import tqdm

import heapq

from gensim.models.word2vec import Word2Vec
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer

import jieba

def get_stop_list(stop_list_name):
    """
    得到停用词表

    @param stop_list_name: 停用词表的文件名
    @return: 包含停用词表的list
    """
    
    with open(stop_list_name, "r") as f:
        stop_list = f.readlines()

    stop_list = list(map(lambda c: c.replace("\n", ""), stop_list))
    return stop_list

def store_cut_data(store_path, data, cut_titles):
    print(len(cut_titles))
    with open(store_path, "w") as f:
        ids = data["id"].tolist()
        L = len(ids)
        for i in range(L):
            id_ = ids[i]
            title_ = " ".join(cut_titles[i])

            f.write(str(id_) + "," + title_ + "\n")



if __name__ == '__main__':

    use_stop = True
    train_data_filepath = "./train_data.csv"
    test_data_filepath = "./test_data.csv"
    stop_list_path = "stop.txt"
    word_embedding_size = 80
    word2vec_model_path = "word2vec.model"

    # 读取数据
    train = pd.read_csv(train_data_filepath)
    test = pd.read_csv(test_data_filepath, encoding="gbk")

    titles_train = train["title"].tolist()
    titles_test = test["title"].tolist()

    stop_list = get_stop_list(stop_list_path)


    # 分词

    cut_titles_train = []
    for title in tqdm(titles_train):
        cut_title_train = jieba.cut(title)
        cut_title_train = [word for word in cut_title_train if use_stop and (word not in stop_list)]
        cut_titles_train.append(cut_title_train)

    cut_titles_test = []

    for title in tqdm(titles_test):
        cut_title_test = jieba.cut(title)
        cut_title_test = [word for word in cut_title_test if use_stop and (word not in stop_list)]
        cut_titles_test.append(cut_title_test)

    store_cut_data("cut_train.csv", train, cut_titles_train)
    print(len(test))
    store_cut_data("cut_test.csv", test, cut_titles_test)

    all_titles = cut_titles_train + cut_titles_test

    corpus = []

    for title in all_titles:
        corpus.append(" ".join(title))

    # tfidf
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(corpus)

    transformer = TfidfTransformer()

    tfidf = transformer.fit_transform(X)

    #  weight = tfidf.toarray()


    l_train = len(cut_titles_train)
    l_test = len(cut_titles_test)

    #  print(len(weight[0]))

    #  with open("res.txt", "w") as f:
        #  f.write("source_id" + "\t" + "target_id" + "\n")
#
        #  ids = test["id"].tolist()
        #  train_ids = train["id"].tolist()
        #  for i in tqdm(range(l_test)):
            #  source_id = ids[i]
#
            #  sim = []
#
            #  source_weight = weight[i + l_train]
#
            #  for j in tqdm(range(l_train)):
                #  target_weight = weight[j]
                #  target_id = train_ids[j]
#
                #  simility = get_simility(source_weight, target_weight)
#
                #  if simility is not None:
                    #  sim.append((simility, target_id))
#
            #  largest_sim = heapq.nlargest(20, sim, key=lambda x: x[0])
#
            #  for l_sim in largest_sim:
                #  f.write(str(source_id) + "\t" + str(l_sim[1]) + "\n")



    #  训练词向量
    sentences = cut_titles_train + cut_titles_test
    model = Word2Vec(sentences, size=word_embedding_size, window=5, min_count=5)
    model.save(word2vec_model_path)

    train_vecs = {}
    train_ids = train["id"].tolist()
    test_ids = test["id"].tolist()

    for i in tqdm(range(l_train)):
        vec = [0 for i in range(word_embedding_size)]

        for word in cut_titles_train[i]:

            if word not in model.wv.vocab:
                continue

            vec_ = model.wv[word]

            for j in range(word_embedding_size):
                vec[j] += vec_[j]
        for j in range(word_embedding_size):
            vec[j] /= (1.0 * len(cut_titles_train))
        train_vecs[train_ids[i]] = vec

    test_vecs = {}
    for i in tqdm(range(l_test)):
        vec = [0 for i in range(word_embedding_size)]

        for word in cut_titles_test[i]:
            if word not in model.wv.vocab:
                continue

            vec_ = model.wv[word]

            for j in range(word_embedding_size):
                vec[j] += vec_[j]

        for j in range(word_embedding_size):
            vec[j] /= (1.0 * len(cut_titles_test[i]))

        test_vecs[test_ids[i]] = vec

    with open("res1.txt", "w") as f:
        for i in tqdm(range(l_test)):

            source_id = test_ids[i]

            source_weight = test_vecs[source_id]

            sim = []
            for j in range(l_train):
                target_id = train_ids[j]
                target_weight = train_vecs[target_id]

                similarity = get_simility(source_weight, target_weight)

                sim.append([target_id, similarity]) 
            best_sims = heapq.nlargest(20, sim, key=lambda x: x[1])

            for b_sim in best_sims:
                f.write(str(source_id) + "\t" + str(b_sim[0]) + "\n")
