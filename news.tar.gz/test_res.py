import pandas as pd

train = pd.read_csv("./train_data")
test = pd.read_csv("./test_data.csv", encoding="gbk")

with open("res.txt", "r") as f:
    lines = f.readlines()

    lineS = lines[1].split("\t")


