import os
import sys


from sklearn.decomposition import PCA

if __name__ == '__main__':
    a = [[1, 2, 3], [0, 1, 2], [3, 1, 4], [1, 3, 5]]

    pca = PCA(2)

    a = pca.fit_transform(a)

    print(a)

