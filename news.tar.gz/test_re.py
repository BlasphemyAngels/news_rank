import re

if __name__ == '__main__':
    a = "2017年10月1日1:0和你123在1.2一起20:00,哈2.1%哈,([asd]http:www.baidu)"

    k1 = r"\(.*\)"
    k2 = r"\[.*\]"

    a = re.sub(k1, "", a)
    a = re.sub(k2, "", a)

    t1 = "[\d]+年"
    t2 = "[\d]+年[\d]+月"
    t3 = "[\d]+年[\d]+月[\d]+日"
    t4 = "[\d]+月[\d]+日"

    
    tt = "[\d]+:[\d]+"

    tt1 = t1 + tt
    tt2 = t2 + tt
    tt3 = t3 + tt
    tt4 = t4 + tt
    print(tt3)

    a = re.sub(tt3, "TIME", a)
    a = re.sub(tt4, "TIME", a)
    a = re.sub(tt2, "TIME", a)
    a = re.sub(tt1, "TIME", a)
    a = re.sub(t3, "TIME", a)
    a = re.sub(t4, "TIME", a)
    a = re.sub(t2, "TIME", a)
    a = re.sub(t1, "TIME", a)
    a = re.sub(tt, "TIME", a)

    n1 = r"[\d]+\.?[\d]*%?"

    a = re.sub(n1, "NUM", a)

    print(a)
